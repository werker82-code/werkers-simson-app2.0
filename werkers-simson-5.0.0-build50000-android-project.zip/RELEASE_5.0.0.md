# Werkers Simson 5.0.0 · Build 50000

Release-Datum: 24. August 2026

## Enthalten

- gemeinsamer Webstand für Android und iOS
- 3D-only-S51-Konfigurator auf Basis GLB 5.0 HD
- 45 separat austauschbare HD-GLB-Baugruppen
- S51 B1-4 und S51 Enduro als eigenständige Grundmodelle
- direkte Startseiten-Navigation zum 3D-Konfigurator
- vollständiges Offline-Bundle inklusive Three.js und GLB-Dateien
- Android-Projekt für API 36
- iOS-Xcode-Projekt für iOS 15+ und Xcode 26+

## Versionsdaten

- Android `versionName`: `5.0.0`
- Android `versionCode`: `50000`
- iOS `CFBundleShortVersionString`: `5.0.0`
- iOS `CFBundleVersion`: `50000`
- Android Application ID: `com.werkers_werkstatt.meineapp`

## Noch außerhalb dieses Pakets erforderlich

- Android: privater Upload-Key, Android SDK 36 und signierter AAB-Build
- iOS: macOS, Xcode 26+, Apple Developer Team und signiertes Archiv
- abschließender Test auf mindestens einem echten Android- und iOS-Gerät
