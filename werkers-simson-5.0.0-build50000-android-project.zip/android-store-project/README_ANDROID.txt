ANDROID-STUDIO-TEMPLATE

Dieses Verzeichnis ist ein natives WebView-Android-Studio-Projekt mit den Offline-Webdateien unter app/src/main/assets.

Öffnen:
1. Android Studio → Open → Ordner android-store-project wählen.
2. Gradle Sync ausführen.
3. Android SDK 36 installieren, falls Android Studio danach fragt.
4. Build → Build APK(s) oder Generate Signed Bundle / APK.

Hinweis: Der parallel enthaltene Capacitor-Weg bleibt ebenfalls verfügbar.
