GOOGLE PLAY RELEASE
===================
Projektstatus:
- applicationId: com.werkerswerkstatt.simson
- versionName: 5.0.0
- versionCode: 50000
- minSdk: 24
- targetSdk/compileSdk: 36 (Android 16)
- keine INTERNET-Berechtigung im nativen Release
- lokale WebView-Inhalte; externe Links werden an den Systembrowser übergeben
- Datei-/Fotoauswahl über Android-Dateiauswahl

Zum Erzeugen eines AAB:
1. Projekt in Android Studio Otter 2025.2.1 oder neuer öffnen.
2. JDK 17 oder neuer verwenden.
3. Gradle-Sync durchführen.
4. Build > Generate Signed App Bundle or APK > Android App Bundle.
5. Upload-Key erstellen/auswählen und Release-AAB signieren.
6. AAB in Play Console hochladen.

Hinweis:
Die Gradle-Wrapper-Eigenschaft ist vorbereitet. Falls `gradlew` noch nicht vorhanden
ist, das Projekt direkt in Android Studio öffnen; Android Studio synchronisiert die
benötigte Gradle-Version.
