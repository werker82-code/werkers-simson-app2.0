# Third-party notices

The high-detail S51 B1-4 preview uses selected, locally bundled files from
[three.js](https://threejs.org/) 0.180.0:

- `three.module.min.js`
- `three.core.min.js`
- `GLTFLoader.js`
- `BufferGeometryUtils.js`
- `RoomEnvironment.js`

three.js is distributed under the MIT License. The complete license text is
stored at `assets/vendor/three/LICENSE.txt` and `www/assets/vendor/three/LICENSE.txt`.

No runtime CDN request is required. The renderer and the complete GLB remain
available to the PWA and Capacitor app offline.
