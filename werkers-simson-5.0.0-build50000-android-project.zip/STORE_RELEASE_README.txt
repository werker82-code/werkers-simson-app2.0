WERKERS SIMSON – STORE RELEASE 5.0.0 (BUILD 50000)
==============================================

Dieses Paket enthält den aktuellen gemeinsamen Android-/iOS-Stand mit dem
3D-Konfigurator GLB 5.0 HD und ist für die Store-Einreichung vorbereitet.

Enthalten:
- vollständige Web-/PWA-App mit 3D-only-Konfigurator
- 45 separat austauschbare HD-GLB-Baugruppen
- S51 B1-4 und S51 Enduro als HD-Grundmodelle
- Capacitor-8-Konfiguration für Android und iOS
- Android-Store-Projekt mit targetSdk/compileSdk 36
- direkt öffnungsfähiges iOS-Xcode-Projekt für Xcode 26+
- Google-Play-Metadaten
- Apple-App-Store-Metadaten
- Datenschutz- und Supportseiten
- Data-Safety/App-Privacy-Vorschläge
- Store-Icon und Feature Graphic
- bestehende Store-Screenshots; für 5.0.0 aktuelle 3D-Ansichten auf echten Geräten
  oder Simulatoren neu aufnehmen
- Store-Freigabecheckliste

WAS NOCH NICHT IM PAKET SEIN KANN
- signiertes Google-Play-AAB: benötigt Android SDK 36 und deinen privaten Upload-Key
- signiertes Apple-Archiv/IPA: benötigt macOS, Xcode 26+ und dein Apple Developer Team
- tatsächlicher Upload in Play Console/App Store Connect

CAPACITOR 8
- Node.js 22+
- Android Studio Otter 2025.2.1+
- Android API 36
- iOS 15+ Deployment Target
- Xcode 26+

GOOGLE PLAY
Öffne `android-store-project` in Android Studio und erzeuge:
Build > Generate Signed App Bundle or APK > Android App Bundle

APPLE
Auf einem Mac `ios-store-project/WerkersSimson.xcodeproj` öffnen, Team auswählen,
auf einem Gerät testen und anschließend Product > Archive verwenden.

Vor dem Store-Upload die Dateien aus `store-submission/legal` auf deiner Website
öffentlich per HTTPS bereitstellen und die URLs in den Store-Einträgen prüfen.
